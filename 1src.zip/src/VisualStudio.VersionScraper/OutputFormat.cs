﻿namespace VisualStudio.VersionScraper;

internal enum OutputFormat
{
    Json,

    CSharp,
}
